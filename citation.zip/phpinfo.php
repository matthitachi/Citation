<?php
phpinfo();


?>


