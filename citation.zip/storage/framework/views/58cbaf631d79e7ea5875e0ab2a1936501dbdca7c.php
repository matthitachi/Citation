<?php
/**
 * Created by PhpStorm.
 * User: ITACHI
 * Date: 10/21/2018
 * Time: 9:29 AM
 */


//if(isset($_GET['type']) && $_GET['type'] !='null'){
//    $citation_type = $_GET['type'];
//
//?>


<?php $__env->startSection('style', strtoupper($style)); ?>
<?php $__env->startSection('navbar'); ?>
    ##parent-placeholder-c63e3c1cfa2ff651ad4cfadea3e21265ffcf8ca3##
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <div class="form-body m-5">
        <h3 class="modal-title">Bibliography :</h3>
        <form>
            <div class="form-group">
                <div style="height: 200px; width: 100%; background-color: white; font-size: 17px;" class="p-5" id="cite_input"><?php echo session('result'); ?> </div>
            </div>
            <h6 id="cite_info">Citation information in <?php echo e(strtoupper($style)); ?> format.</h6>

            <div class="form-group">
                <button type="button" class="btn btn-primary"  onclick="cite_copy()" >copy</button>
                <a href="/" class="btn btn-secondary" >Close</a>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content_desc'); ?>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>